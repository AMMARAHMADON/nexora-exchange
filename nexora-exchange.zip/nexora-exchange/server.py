#!/usr/bin/env python3
"""
NEXORA Exchange — demo trading platform + e-wallet.
Simulation only. No real money, no licensed brokerage.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import math
import os
import random
import secrets
import sqlite3
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT / "public"
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)
DB_PATH = DATA / "nexora.db"
HOST = os.environ.get("NEXORA_HOST", "0.0.0.0")
PORT = int(os.environ.get("NEXORA_PORT", "8080"))
SECRET = os.environ.get("NEXORA_SECRET", "nexora-demo-secret-change-me")

ASSETS = {
    "USDT": {"name": "Tether USD", "kind": "stable", "decimals": 2, "networks": ["TRC20", "ERC20", "BEP20"]},
    "USD": {"name": "US Dollar", "kind": "fiat", "decimals": 2, "networks": ["BANK"]},
    "AED": {"name": "UAE Dirham", "kind": "fiat", "decimals": 2, "networks": ["BANK"]},
    "BTC": {"name": "Bitcoin", "kind": "crypto", "decimals": 8, "networks": ["Bitcoin", "Lightning"]},
    "ETH": {"name": "Ethereum", "kind": "crypto", "decimals": 6, "networks": ["ERC20", "Arbitrum"]},
    "SOL": {"name": "Solana", "kind": "crypto", "decimals": 4, "networks": ["Solana"]},
    "BNB": {"name": "BNB", "kind": "crypto", "decimals": 4, "networks": ["BEP20"]},
    "XRP": {"name": "XRP", "kind": "crypto", "decimals": 4, "networks": ["XRPL"]},
    "DOGE": {"name": "Dogecoin", "kind": "crypto", "decimals": 2, "networks": ["Dogecoin"]},
    "TON": {"name": "Toncoin", "kind": "crypto", "decimals": 4, "networks": ["TON"]},
}

PAIRS = [
    ("BTC", "USDT"),
    ("ETH", "USDT"),
    ("SOL", "USDT"),
    ("BNB", "USDT"),
    ("XRP", "USDT"),
    ("DOGE", "USDT"),
    ("TON", "USDT"),
    ("ETH", "BTC"),
]

COINGECKO_IDS = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "SOL": "solana",
    "BNB": "binancecoin",
    "XRP": "ripple",
    "DOGE": "dogecoin",
    "TON": "the-open-network",
}

SEED_PRICES = {
    "BTC": 64250.0,
    "ETH": 2480.0,
    "SOL": 148.5,
    "BNB": 575.0,
    "XRP": 0.62,
    "DOGE": 0.118,
    "TON": 5.42,
    "USDT": 1.0,
    "USD": 1.0,
    "AED": 0.2723,
}

MIME = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".ico": "image/x-icon",
    ".woff2": "font/woff2",
}


def now():
    return time.time()


def iso(ts=None):
    ts = ts if ts is not None else now()
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts))


def hash_pw(password: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000).hex()


def token_sign(user_id: int) -> str:
    raw = f"{user_id}.{int(now())}.{secrets.token_hex(16)}"
    sig = hmac.new(SECRET.encode(), raw.encode(), hashlib.sha256).hexdigest()[:24]
    return f"{raw}.{sig}"


def db():
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA foreign_keys=ON")
    return con


LOCK = threading.RLock()
MARKET = {
    "prices": dict(SEED_PRICES),
    "change24": {k: 0.0 for k in SEED_PRICES},
    "vol24": {k: 0.0 for k in SEED_PRICES},
    "high24": dict(SEED_PRICES),
    "low24": dict(SEED_PRICES),
    "candles": {},  # pair -> list of [t,o,h,l,c,v]
    "books": {},
    "tape": {},
    "last_fetch": 0.0,
}


def init_db():
    con = db()
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            salt TEXT NOT NULL,
            pw TEXT NOT NULL,
            created_at REAL NOT NULL,
            kyc TEXT NOT NULL DEFAULT 'unverified',
            lang TEXT NOT NULL DEFAULT 'en',
            referral TEXT
        );
        CREATE TABLE IF NOT EXISTS sessions (
            token TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            created_at REAL NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS balances (
            user_id INTEGER NOT NULL,
            asset TEXT NOT NULL,
            available REAL NOT NULL DEFAULT 0,
            locked REAL NOT NULL DEFAULT 0,
            PRIMARY KEY(user_id, asset),
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS addresses (
            user_id INTEGER NOT NULL,
            asset TEXT NOT NULL,
            network TEXT NOT NULL,
            address TEXT NOT NULL,
            PRIMARY KEY(user_id, asset, network)
        );
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            pair TEXT NOT NULL,
            side TEXT NOT NULL,
            type TEXT NOT NULL,
            price REAL,
            amount REAL NOT NULL,
            filled REAL NOT NULL DEFAULT 0,
            status TEXT NOT NULL,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS fills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER,
            user_id INTEGER NOT NULL,
            pair TEXT NOT NULL,
            side TEXT NOT NULL,
            price REAL NOT NULL,
            amount REAL NOT NULL,
            fee REAL NOT NULL,
            created_at REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS txs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            kind TEXT NOT NULL,
            asset TEXT NOT NULL,
            amount REAL NOT NULL,
            fee REAL NOT NULL DEFAULT 0,
            status TEXT NOT NULL,
            meta TEXT,
            created_at REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS stakes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            asset TEXT NOT NULL,
            amount REAL NOT NULL,
            apr REAL NOT NULL,
            days INTEGER NOT NULL,
            started_at REAL NOT NULL,
            ends_at REAL NOT NULL,
            status TEXT NOT NULL
        );
        """
    )
    # Seed demo user
    cur = con.execute("SELECT id FROM users WHERE email=?", ("ammar@nexora.demo",))
    row = cur.fetchone()
    if not row:
        salt = secrets.token_hex(8)
        con.execute(
            "INSERT INTO users(name,email,salt,pw,created_at,kyc,referral) VALUES(?,?,?,?,?,?,?)",
            ("Ammar", "ammar@nexora.demo", salt, hash_pw("demo1234", salt), now(), "verified", "AMMAR10"),
        )
        uid = con.execute("SELECT id FROM users WHERE email=?", ("ammar@nexora.demo",)).fetchone()[0]
        starters = {
            "USDT": 50000,
            "USD": 8000,
            "AED": 25000,
            "BTC": 0.35,
            "ETH": 4.2,
            "SOL": 40,
            "BNB": 8,
            "XRP": 2500,
            "DOGE": 12000,
            "TON": 180,
        }
        for a, amt in starters.items():
            con.execute(
                "INSERT INTO balances(user_id,asset,available,locked) VALUES(?,?,?,0)",
                (uid, a, amt),
            )
        _ensure_addresses(con, uid)
        # second user for P2P transfer demo
        salt2 = secrets.token_hex(8)
        con.execute(
            "INSERT INTO users(name,email,salt,pw,created_at,kyc,referral) VALUES(?,?,?,?,?,?,?)",
            ("Sara Khan", "sara@nexora.demo", salt2, hash_pw("demo1234", salt2), now(), "verified", "SARA10"),
        )
        uid2 = con.execute("SELECT id FROM users WHERE email=?", ("sara@nexora.demo",)).fetchone()[0]
        con.execute("INSERT INTO balances(user_id,asset,available,locked) VALUES(?,?,?,0)", (uid2, "USDT", 12000))
        _ensure_addresses(con, uid2)
    con.commit()
    con.close()


def _ensure_addresses(con, uid):
    prefixes = {
        "BTC": "bc1q",
        "ETH": "0x",
        "SOL": "So",
        "BNB": "0x",
        "XRP": "r",
        "DOGE": "D",
        "TON": "UQ",
        "USDT": "T",
        "USD": "NEX-",
        "AED": "NEX-",
    }
    for asset, meta in ASSETS.items():
        for net in meta["networks"]:
            exists = con.execute(
                "SELECT 1 FROM addresses WHERE user_id=? AND asset=? AND network=?",
                (uid, asset, net),
            ).fetchone()
            if exists:
                continue
            rnd = secrets.token_hex(10)
            addr = prefixes.get(asset, "nx") + rnd
            con.execute(
                "INSERT INTO addresses(user_id,asset,network,address) VALUES(?,?,?,?)",
                (uid, asset, net, addr),
            )


def pair_key(base, quote):
    return f"{base}/{quote}"


def parse_pair(p):
    base, quote = p.split("/")
    return base, quote


def gen_candles(base, quote, n=240, step=300):
    px = MARKET["prices"].get(base, 1) / max(MARKET["prices"].get(quote, 1), 1e-12)
    if quote in ("USDT", "USD"):
        px = MARKET["prices"].get(base, 1)
    candles = []
    t = now() - n * step
    price = px * (0.97 + random.random() * 0.03)
    for i in range(n):
        drift = (px - price) * 0.04
        ch = price * random.uniform(-0.006, 0.006) + drift
        o = price
        c = max(price + ch, px * 0.2)
        h = max(o, c) * (1 + random.uniform(0, 0.004))
        l = min(o, c) * (1 - random.uniform(0, 0.004))
        v = random.uniform(12, 420) * (px / max(px, 1) ** 0.3)
        candles.append([int(t + i * step), round(o, 8), round(h, 8), round(l, 8), round(c, 8), round(v, 4)])
        price = c
    return candles


def gen_book(mid, depth=14):
    bids, asks = [], []
    for i in range(depth):
        off = (i + 1) * mid * random.uniform(0.00025, 0.00055)
        bids.append({"price": round(mid - off, 8), "amount": round(random.uniform(0.05, 4.8) * (1 + i * 0.15), 6)})
        asks.append({"price": round(mid + off, 8), "amount": round(random.uniform(0.05, 4.8) * (1 + i * 0.15), 6)})
    bids.sort(key=lambda x: -x["price"])
    asks.sort(key=lambda x: x["price"])
    return {"bids": bids, "asks": asks}


def last_price(pair):
    base, quote = parse_pair(pair)
    bp = MARKET["prices"].get(base, 1)
    qp = MARKET["prices"].get(quote, 1)
    if quote in ("USDT", "USD"):
        return bp
    return bp / max(qp, 1e-12)


def refresh_markets(force=False):
    if not force and now() - MARKET["last_fetch"] < 20:
        return
    try:
        ids = ",".join(COINGECKO_IDS.values())
        url = "https://api.coingecko.com/api/v3/simple/price?" + urllib.parse.urlencode(
            {
                "ids": ids,
                "vs_currencies": "usd",
                "include_24hr_change": "true",
                "include_24hr_vol": "true",
            }
        )
        req = urllib.request.Request(url, headers={"User-Agent": "NexoraExchange/1.0"})
        with urllib.request.urlopen(req, timeout=6) as resp:
            data = json.loads(resp.read().decode())
        for sym, cid in COINGECKO_IDS.items():
            row = data.get(cid) or {}
            if "usd" in row:
                MARKET["prices"][sym] = float(row["usd"])
            MARKET["change24"][sym] = float(row.get("usd_24h_change") or 0)
            MARKET["vol24"][sym] = float(row.get("usd_24h_vol") or 0)
            p = MARKET["prices"][sym]
            ch = MARKET["change24"][sym] / 100.0
            prev = p / max(1 + ch, 1e-9)
            MARKET["high24"][sym] = max(p, prev) * 1.004
            MARKET["low24"][sym] = min(p, prev) * 0.996
        MARKET["last_fetch"] = now()
    except Exception:
        # offline / rate-limited: random walk
        for sym in COINGECKO_IDS:
            p = MARKET["prices"][sym]
            p = p * (1 + random.uniform(-0.0015, 0.0015))
            MARKET["prices"][sym] = p
            MARKET["change24"][sym] = MARKET["change24"].get(sym, 0) + random.uniform(-0.05, 0.05)
        MARKET["last_fetch"] = now()

    for base, quote in PAIRS:
        pk = pair_key(base, quote)
        mid = last_price(pk)
        if pk not in MARKET["candles"] or random.random() < 0.35:
            MARKET["candles"][pk] = gen_candles(base, quote)
        else:
            candles = MARKET["candles"][pk]
            last = candles[-1]
            tnow = int(now())
            if tnow - last[0] >= 300:
                o = last[4]
                c = mid
                h = max(o, c) * (1 + random.uniform(0, 0.002))
                l = min(o, c) * (1 - random.uniform(0, 0.002))
                candles.append([tnow, o, h, l, c, random.uniform(8, 200)])
                MARKET["candles"][pk] = candles[-240:]
            else:
                last[2] = max(last[2], mid)
                last[3] = min(last[3], mid)
                last[4] = mid
        MARKET["books"][pk] = gen_book(mid)
        tape = MARKET["tape"].setdefault(pk, [])
        if random.random() < 0.7:
            side = random.choice(["buy", "sell"])
            tape.insert(
                0,
                {
                    "id": secrets.token_hex(4),
                    "price": round(mid * (1 + random.uniform(-0.0008, 0.0008)), 8),
                    "amount": round(random.uniform(0.002, 1.6), 6),
                    "side": side,
                    "ts": now(),
                },
            )
            MARKET["tape"][pk] = tape[:40]


def market_tick_loop():
    while True:
        try:
            refresh_markets()
        except Exception:
            traceback.print_exc()
        time.sleep(8)


def get_user_by_token(con, token):
    if not token:
        return None
    row = con.execute("SELECT user_id FROM sessions WHERE token=?", (token,)).fetchone()
    if not row:
        return None
    return con.execute("SELECT * FROM users WHERE id=?", (row["user_id"],)).fetchone()


def ensure_balance_row(con, uid, asset):
    con.execute(
        "INSERT OR IGNORE INTO balances(user_id,asset,available,locked) VALUES(?,?,0,0)",
        (uid, asset),
    )


def get_bal(con, uid, asset):
    ensure_balance_row(con, uid, asset)
    return con.execute(
        "SELECT available, locked FROM balances WHERE user_id=? AND asset=?",
        (uid, asset),
    ).fetchone()


def add_bal(con, uid, asset, avail=0.0, locked=0.0):
    ensure_balance_row(con, uid, asset)
    con.execute(
        "UPDATE balances SET available=available+?, locked=locked+? WHERE user_id=? AND asset=?",
        (avail, locked, uid, asset),
    )


def portfolio(con, uid):
    rows = con.execute("SELECT asset, available, locked FROM balances WHERE user_id=?", (uid,)).fetchall()
    items = []
    total = 0.0
    for r in rows:
        px = MARKET["prices"].get(r["asset"], 0)
        usd = (r["available"] + r["locked"]) * px
        total += usd
        items.append(
            {
                "asset": r["asset"],
                "name": ASSETS[r["asset"]]["name"],
                "kind": ASSETS[r["asset"]]["kind"],
                "available": r["available"],
                "locked": r["locked"],
                "usd": usd,
                "price": px,
            }
        )
    items.sort(key=lambda x: -x["usd"])
    return {"total_usd": total, "assets": items}


def json_markets():
    out = []
    for base, quote in PAIRS:
        pk = pair_key(base, quote)
        px = last_price(pk)
        ch = MARKET["change24"].get(base, 0)
        if quote not in ("USDT", "USD"):
            ch = MARKET["change24"].get(base, 0) - MARKET["change24"].get(quote, 0)
        out.append(
            {
                "pair": pk,
                "base": base,
                "quote": quote,
                "price": px,
                "change24": ch,
                "high24": MARKET["high24"].get(base, px) if quote in ("USDT", "USD") else px * 1.01,
                "low24": MARKET["low24"].get(base, px) if quote in ("USDT", "USD") else px * 0.99,
                "vol24": MARKET["vol24"].get(base, 0),
            }
        )
    return out


def match_order(con, order_id):
    o = con.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] not in ("open", "partial"):
        return
    pair = o["pair"]
    mid = last_price(pair)
    base, quote = parse_pair(pair)
    remaining = o["amount"] - o["filled"]
    can = False
    fill_px = mid
    if o["type"] == "market":
        can = True
        slip = 1.0004 if o["side"] == "buy" else 0.9996
        fill_px = mid * slip
    elif o["type"] == "limit":
        if o["side"] == "buy" and o["price"] >= mid:
            can = True
            fill_px = min(o["price"], mid)
        if o["side"] == "sell" and o["price"] <= mid:
            can = True
            fill_px = max(o["price"], mid)
    if not can:
        return
    fee_rate = 0.001
    if o["side"] == "buy":
        locked_px = o["price"] or fill_px
        locked_cost = remaining * locked_px
        cost = remaining * fill_px
        fee = remaining * fee_rate
        add_bal(con, o["user_id"], quote, avail=locked_cost - cost, locked=-locked_cost)
        add_bal(con, o["user_id"], base, avail=remaining - fee, locked=0)
        leftover = 0  # fully filled at mark
        con.execute(
            "INSERT INTO fills(order_id,user_id,pair,side,price,amount,fee,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (o["id"], o["user_id"], pair, "buy", fill_px, remaining, fee, now()),
        )
        con.execute(
            "INSERT INTO txs(user_id,kind,asset,amount,fee,status,meta,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (o["user_id"], "trade_buy", base, remaining - fee, fee, "completed", pair, now()),
        )
    else:
        fee = remaining * fill_px * fee_rate
        proceeds = remaining * fill_px - fee
        add_bal(con, o["user_id"], base, avail=0, locked=-remaining)
        add_bal(con, o["user_id"], quote, avail=proceeds, locked=0)
        con.execute(
            "INSERT INTO fills(order_id,user_id,pair,side,price,amount,fee,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (o["id"], o["user_id"], pair, "sell", fill_px, remaining, fee, now()),
        )
        con.execute(
            "INSERT INTO txs(user_id,kind,asset,amount,fee,status,meta,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (o["user_id"], "trade_sell", quote, proceeds, fee, "completed", pair, now()),
        )
    con.execute(
        "UPDATE orders SET filled=amount, status='filled', updated_at=? WHERE id=?",
        (now(), o["id"]),
    )
    tape = MARKET["tape"].setdefault(pair, [])
    tape.insert(
        0,
        {"id": secrets.token_hex(4), "price": fill_px, "amount": remaining, "side": o["side"], "ts": now()},
    )


class Handler(BaseHTTPRequestHandler):
    server_version = "Nexora/1.0"

    def log_message(self, fmt, *args):
        print(f"[{iso()}] {self.address_string()} {fmt % args}")

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            raw = json.dumps(body, default=str).encode()
        elif isinstance(body, str):
            raw = body.encode()
        else:
            raw = body
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _err(self, code, msg):
        self._send(code, {"ok": False, "error": msg})

    def _read_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n == 0:
            return {}
        return json.loads(self.rfile.read(n).decode() or "{}")

    def _auth(self, con):
        hdr = self.headers.get("Authorization") or ""
        token = hdr.replace("Bearer", "").strip()
        if not token:
            q = urllib.parse.urlparse(self.path).query
            token = urllib.parse.parse_qs(q).get("token", [""])[0]
        return get_user_by_token(con, token)

    def do_GET(self):
        try:
            self._route("GET")
        except Exception as e:
            traceback.print_exc()
            self._err(500, str(e))

    def do_POST(self):
        try:
            self._route("POST")
        except Exception as e:
            traceback.print_exc()
            self._err(500, str(e))

    def do_DELETE(self):
        try:
            self._route("DELETE")
        except Exception as e:
            traceback.print_exc()
            self._err(500, str(e))

    def _route(self, method):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        qs = urllib.parse.parse_qs(parsed.query)

        if not path.startswith("/api"):
            return self._static(path)

        refresh_markets()
        con = db()
        try:
            with LOCK:
                return self._api(method, path, qs, con)
        finally:
            con.close()

    def _static(self, path):
        if path == "/":
            path = "/index.html"
        target = (PUBLIC / path.lstrip("/")).resolve()
        if PUBLIC.resolve() not in target.parents and target != PUBLIC.resolve():
            return self._err(403, "forbidden")
        if not target.is_file():
            # SPA fallback
            target = PUBLIC / "index.html"
        data = target.read_bytes()
        self._send(200, data, MIME.get(target.suffix, "application/octet-stream"))

    def _api(self, method, path, qs, con):
        if method == "POST" and path == "/api/register":
            body = self._read_json()
            name = (body.get("name") or "").strip()
            email = (body.get("email") or "").strip().lower()
            password = body.get("password") or ""
            if len(name) < 2 or "@" not in email or len(password) < 6:
                return self._err(400, "Name, valid email and password (6+ chars) required")
            if con.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
                return self._err(409, "Email already registered")
            salt = secrets.token_hex(8)
            con.execute(
                "INSERT INTO users(name,email,salt,pw,created_at) VALUES(?,?,?,?,?)",
                (name, email, salt, hash_pw(password, salt), now()),
            )
            uid = con.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()[0]
            con.execute("INSERT INTO balances(user_id,asset,available,locked) VALUES(?,?,?,0)", (uid, "USDT", 10000))
            con.execute("INSERT INTO balances(user_id,asset,available,locked) VALUES(?,?,?,0)", (uid, "AED", 5000))
            _ensure_addresses(con, uid)
            token = token_sign(uid)
            con.execute("INSERT INTO sessions(token,user_id,created_at) VALUES(?,?,?)", (token, uid, now()))
            con.commit()
            return self._send(200, {"ok": True, "token": token, "user": self._user_json(con, uid)})

        if method == "POST" and path == "/api/login":
            body = self._read_json()
            email = (body.get("email") or "").strip().lower()
            password = body.get("password") or ""
            u = con.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
            if not u or hash_pw(password, u["salt"]) != u["pw"]:
                return self._err(401, "Invalid email or password")
            token = token_sign(u["id"])
            con.execute("INSERT INTO sessions(token,user_id,created_at) VALUES(?,?,?)", (token, u["id"], now()))
            con.commit()
            return self._send(200, {"ok": True, "token": token, "user": self._user_json(con, u["id"])})

        if path == "/api/markets" and method == "GET":
            return self._send(200, {"ok": True, "markets": json_markets(), "updated": iso()})

        if path.startswith("/api/orderbook/") and method == "GET":
            pair = path.split("/api/orderbook/", 1)[1].upper()
            book = MARKET["books"].get(pair) or gen_book(last_price(pair) if "/" in pair else 1)
            return self._send(200, {"ok": True, "pair": pair, **book, "mid": last_price(pair)})

        if path.startswith("/api/candles/") and method == "GET":
            pair = path.split("/api/candles/", 1)[1].upper()
            return self._send(200, {"ok": True, "pair": pair, "candles": MARKET["candles"].get(pair, [])})

        if path.startswith("/api/tape/") and method == "GET":
            pair = path.split("/api/tape/", 1)[1].upper()
            return self._send(200, {"ok": True, "trades": MARKET["tape"].get(pair, [])})

        user = self._auth(con)
        if not user:
            return self._err(401, "Sign in required")
        uid = user["id"]

        if path == "/api/me" and method == "GET":
            return self._send(200, {"ok": True, "user": self._user_json(con, uid), "portfolio": portfolio(con, uid)})

        if path == "/api/wallet" and method == "GET":
            addrs = [
                dict(r)
                for r in con.execute(
                    "SELECT asset, network, address FROM addresses WHERE user_id=?", (uid,)
                ).fetchall()
            ]
            return self._send(200, {"ok": True, "portfolio": portfolio(con, uid), "addresses": addrs})

        if path == "/api/wallet/deposit" and method == "POST":
            body = self._read_json()
            asset = (body.get("asset") or "").upper()
            amount = float(body.get("amount") or 0)
            if asset not in ASSETS or amount <= 0:
                return self._err(400, "Invalid asset or amount")
            add_bal(con, uid, asset, avail=amount)
            con.execute(
                "INSERT INTO txs(user_id,kind,asset,amount,fee,status,meta,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (uid, "deposit", asset, amount, 0, "completed", body.get("network") or "SIM", now()),
            )
            con.commit()
            return self._send(200, {"ok": True, "portfolio": portfolio(con, uid)})

        if path == "/api/wallet/withdraw" and method == "POST":
            body = self._read_json()
            asset = (body.get("asset") or "").upper()
            amount = float(body.get("amount") or 0)
            address = (body.get("address") or "").strip()
            if asset not in ASSETS or amount <= 0 or len(address) < 6:
                return self._err(400, "Asset, amount and destination address required")
            fee = max(amount * 0.001, 0.00000001)
            bal = get_bal(con, uid, asset)
            if bal["available"] < amount + fee:
                return self._err(400, "Insufficient available balance")
            add_bal(con, uid, asset, avail=-(amount + fee))
            con.execute(
                "INSERT INTO txs(user_id,kind,asset,amount,fee,status,meta,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (uid, "withdraw", asset, amount, fee, "completed", address, now()),
            )
            con.commit()
            return self._send(200, {"ok": True, "portfolio": portfolio(con, uid)})

        if path == "/api/wallet/transfer" and method == "POST":
            body = self._read_json()
            asset = (body.get("asset") or "").upper()
            amount = float(body.get("amount") or 0)
            email = (body.get("email") or "").strip().lower()
            dest = con.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
            if not dest:
                return self._err(404, "Recipient not found on Nexora")
            if dest["id"] == uid:
                return self._err(400, "Cannot transfer to yourself")
            if asset not in ASSETS or amount <= 0:
                return self._err(400, "Invalid asset or amount")
            bal = get_bal(con, uid, asset)
            if bal["available"] < amount:
                return self._err(400, "Insufficient available balance")
            add_bal(con, uid, asset, avail=-amount)
            add_bal(con, dest["id"], asset, avail=amount)
            con.execute(
                "INSERT INTO txs(user_id,kind,asset,amount,fee,status,meta,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (uid, "transfer_out", asset, amount, 0, "completed", email, now()),
            )
            con.execute(
                "INSERT INTO txs(user_id,kind,asset,amount,fee,status,meta,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (dest["id"], "transfer_in", asset, amount, 0, "completed", user["email"], now()),
            )
            con.commit()
            return self._send(200, {"ok": True, "portfolio": portfolio(con, uid)})

        if path == "/api/convert" and method == "POST":
            body = self._read_json()
            src = (body.get("from") or "").upper()
            dst = (body.get("to") or "").upper()
            amount = float(body.get("amount") or 0)
            if src not in ASSETS or dst not in ASSETS or src == dst or amount <= 0:
                return self._err(400, "Invalid conversion")
            bal = get_bal(con, uid, src)
            if bal["available"] < amount:
                return self._err(400, "Insufficient available balance")
            usd = amount * MARKET["prices"].get(src, 0)
            got = usd / max(MARKET["prices"].get(dst, 1), 1e-12)
            fee = got * 0.0015
            got -= fee
            add_bal(con, uid, src, avail=-amount)
            add_bal(con, uid, dst, avail=got)
            con.execute(
                "INSERT INTO txs(user_id,kind,asset,amount,fee,status,meta,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (uid, "convert", dst, got, fee, "completed", f"{amount} {src} -> {dst}", now()),
            )
            con.commit()
            return self._send(200, {"ok": True, "received": got, "fee": fee, "portfolio": portfolio(con, uid)})

        if path == "/api/orders" and method == "GET":
            rows = con.execute(
                "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 80", (uid,)
            ).fetchall()
            return self._send(200, {"ok": True, "orders": [dict(r) for r in rows]})

        if path == "/api/orders" and method == "POST":
            body = self._read_json()
            pair = (body.get("pair") or "").upper()
            side = (body.get("side") or "").lower()
            typ = (body.get("type") or "market").lower()
            amount = float(body.get("amount") or 0)
            price = body.get("price")
            price = float(price) if price not in (None, "") else None
            if pair not in [pair_key(*p) for p in PAIRS] or side not in ("buy", "sell") or amount <= 0:
                return self._err(400, "Invalid order")
            if typ == "limit" and (not price or price <= 0):
                return self._err(400, "Limit price required")
            base, quote = parse_pair(pair)
            mid = last_price(pair)
            px = price if typ == "limit" else mid
            if side == "buy":
                cost = amount * px
                bal = get_bal(con, uid, quote)
                if bal["available"] < cost:
                    return self._err(400, f"Need {cost:.6f} {quote}")
                add_bal(con, uid, quote, avail=-cost, locked=cost)
            else:
                bal = get_bal(con, uid, base)
                if bal["available"] < amount:
                    return self._err(400, f"Need {amount} {base}")
                add_bal(con, uid, base, avail=-amount, locked=amount)
            con.execute(
                "INSERT INTO orders(user_id,pair,side,type,price,amount,filled,status,created_at,updated_at) VALUES(?,?,?,?,?,?,0,'open',?,?)",
                (uid, pair, side, typ, px, amount, now(), now()),
            )
            oid = con.execute("SELECT last_insert_rowid()").fetchone()[0]
            match_order(con, oid)
            con.commit()
            o = dict(con.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone())
            return self._send(200, {"ok": True, "order": o, "portfolio": portfolio(con, uid)})

        if path.startswith("/api/orders/") and method == "DELETE":
            oid = int(path.rsplit("/", 1)[1])
            o = con.execute("SELECT * FROM orders WHERE id=? AND user_id=?", (oid, uid)).fetchone()
            if not o:
                return self._err(404, "Order not found")
            if o["status"] not in ("open", "partial"):
                return self._err(400, "Order cannot be cancelled")
            rem = o["amount"] - o["filled"]
            base, quote = parse_pair(o["pair"])
            if o["side"] == "buy":
                add_bal(con, uid, quote, avail=rem * o["price"], locked=-(rem * o["price"]))
            else:
                add_bal(con, uid, base, avail=rem, locked=-rem)
            con.execute("UPDATE orders SET status='cancelled', updated_at=? WHERE id=?", (now(), oid))
            con.commit()
            return self._send(200, {"ok": True, "portfolio": portfolio(con, uid)})

        if path == "/api/fills" and method == "GET":
            rows = con.execute(
                "SELECT * FROM fills WHERE user_id=? ORDER BY id DESC LIMIT 80", (uid,)
            ).fetchall()
            return self._send(200, {"ok": True, "fills": [dict(r) for r in rows]})

        if path == "/api/transactions" and method == "GET":
            rows = con.execute(
                "SELECT * FROM txs WHERE user_id=? ORDER BY id DESC LIMIT 120", (uid,)
            ).fetchall()
            return self._send(200, {"ok": True, "txs": [dict(r) for r in rows]})

        if path == "/api/stake" and method == "GET":
            rows = con.execute(
                "SELECT * FROM stakes WHERE user_id=? ORDER BY id DESC", (uid,)
            ).fetchall()
            out = []
            for r in rows:
                d = dict(r)
                if d["status"] == "active" and now() >= d["ends_at"]:
                    reward = d["amount"] * d["apr"] * (d["days"] / 365.0)
                    add_bal(con, uid, d["asset"], avail=d["amount"] + reward)
                    con.execute("UPDATE stakes SET status='matured' WHERE id=?", (d["id"],))
                    d["status"] = "matured"
                    d["reward"] = reward
                else:
                    elapsed = min(now() - d["started_at"], d["ends_at"] - d["started_at"])
                    d["reward"] = d["amount"] * d["apr"] * (elapsed / (365 * 86400))
                out.append(d)
            con.commit()
            return self._send(200, {"ok": True, "stakes": out})

        if path == "/api/stake" and method == "POST":
            body = self._read_json()
            asset = (body.get("asset") or "").upper()
            amount = float(body.get("amount") or 0)
            days = int(body.get("days") or 30)
            aprs = {"USDT": 0.08, "ETH": 0.045, "SOL": 0.065, "TON": 0.055}
            if asset not in aprs or amount <= 0 or days not in (30, 90, 180):
                return self._err(400, "Stake USDT/ETH/SOL/TON for 30/90/180 days")
            bal = get_bal(con, uid, asset)
            if bal["available"] < amount:
                return self._err(400, "Insufficient available balance")
            add_bal(con, uid, asset, avail=-amount)
            con.execute(
                "INSERT INTO stakes(user_id,asset,amount,apr,days,started_at,ends_at,status) VALUES(?,?,?,?,?,?,?,?)",
                (uid, asset, amount, aprs[asset], days, now(), now() + days * 86400, "active"),
            )
            con.execute(
                "INSERT INTO txs(user_id,kind,asset,amount,fee,status,meta,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (uid, "stake", asset, amount, 0, "completed", f"{days}d @ {aprs[asset]*100:.1f}%", now()),
            )
            con.commit()
            return self._send(200, {"ok": True, "portfolio": portfolio(con, uid)})

        if path == "/api/profile" and method == "POST":
            body = self._read_json()
            name = (body.get("name") or user["name"]).strip()
            lang = body.get("lang") or user["lang"]
            con.execute("UPDATE users SET name=?, lang=? WHERE id=?", (name, lang, uid))
            con.commit()
            return self._send(200, {"ok": True, "user": self._user_json(con, uid)})

        return self._err(404, "Unknown endpoint")

    def _user_json(self, con, uid):
        u = con.execute("SELECT id,name,email,created_at,kyc,lang,referral FROM users WHERE id=?", (uid,)).fetchone()
        return dict(u)


def main():
    init_db()
    refresh_markets(force=True)
    t = threading.Thread(target=market_tick_loop, daemon=True)
    t.start()
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"NEXORA Exchange running at http://127.0.0.1:{PORT}")
    print("Demo login: ammar@nexora.demo  /  demo1234")
    httpd.serve_forever()


if __name__ == "__main__":
    main()
