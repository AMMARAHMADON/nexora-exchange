const $ = (sel, el = document) => el.querySelector(sel);
const app = $("#app");

const state = {
  token: localStorage.getItem("nexora_token") || "",
  user: null,
  portfolio: null,
  markets: [],
  view: "overview",
  pair: "BTC/USDT",
  side: "buy",
  otype: "market",
  book: { bids: [], asks: [] },
  candles: [],
  tape: [],
  orders: [],
  fills: [],
  txs: [],
  stakes: [],
  addresses: [],
  lang: localStorage.getItem("nexora_lang") || "en",
  toast: null,
};

const I18N = {
  en: {
    overview: "Overview", markets: "Markets", trade: "Trade", wallet: "Wallet",
    orders: "Orders", earn: "Earn", settings: "Settings",
    login: "Sign in", register: "Create account",
    demo: "Simulation platform — no real funds, not a licensed exchange.",
    portfolio: "Portfolio value", available: "Available", locked: "Locked",
  },
  ar: {
    overview: "نظرة عامة", markets: "الأسواق", trade: "تداول", wallet: "المحفظة",
    orders: "الأوامر", earn: "عائد", settings: "إعدادات",
    login: "دخول", register: "حساب جديد",
    demo: "منصة محاكاة — ليست أموالاً حقيقية وليست بورصة مرخّصة.",
    portfolio: "قيمة المحفظة", available: "المتاح", locked: "مجمّد",
  },
};
const t = (k) => (I18N[state.lang] || I18N.en)[k] || k;

async function api(path, opts = {}) {
  const headers = { "Content-Type": "application/json" };
  if (state.token) headers.Authorization = "Bearer " + state.token;
  const res = await fetch(path, { ...opts, headers });
  const data = await res.json().catch(() => ({ ok: false, error: "Bad response" }));
  if (!res.ok || data.ok === false) throw new Error(data.error || "Request failed");
  return data;
}

function toast(msg, kind = "ok") {
  state.toast = { msg, kind };
  renderToast();
  setTimeout(() => { state.toast = null; renderToast(); }, 3200);
}
function renderToast() {
  let el = $(".toast");
  if (!state.toast) { if (el) el.remove(); return; }
  if (!el) {
    el = document.createElement("div");
    el.className = "toast";
    el.id = "toast";
    document.body.appendChild(el);
  }
  el.textContent = state.toast.msg;
}

function fmt(n, d = 2) {
  if (n === undefined || n === null || Number.isNaN(n)) return "—";
  const abs = Math.abs(n);
  const digits = abs >= 1000 ? 2 : abs >= 1 ? Math.min(d, 4) : abs >= 0.01 ? 4 : 6;
  return Number(n).toLocaleString(undefined, { maximumFractionDigits: digits });
}
function usd(n) { return "$" + Number(n || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
function clsCh(n) { return n >= 0 ? "up" : "down"; }
function chTxt(n) { return (n >= 0 ? "+" : "") + Number(n || 0).toFixed(2) + "%"; }

function drawChart(canvas, candles) {
  if (!canvas || !candles.length) return;
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth, h = canvas.clientHeight;
  canvas.width = w * dpr; canvas.height = h * dpr;
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, w, h);
  const pad = 12;
  const highs = candles.map(c => c[2]), lows = candles.map(c => c[3]);
  const max = Math.max(...highs), min = Math.min(...lows);
  const span = max - min || 1;
  const cw = (w - pad * 2) / candles.length;
  candles.forEach((c, i) => {
    const x = pad + i * cw + cw / 2;
    const yO = pad + (max - c[1]) / span * (h - pad * 2);
    const yC = pad + (max - c[4]) / span * (h - pad * 2);
    const yH = pad + (max - c[2]) / span * (h - pad * 2);
    const yL = pad + (max - c[3]) / span * (h - pad * 2);
    const up = c[4] >= c[1];
    ctx.strokeStyle = up ? "#1bd17a" : "#ff5c6c";
    ctx.fillStyle = up ? "#1bd17a" : "#ff5c6c";
    ctx.beginPath(); ctx.moveTo(x, yH); ctx.lineTo(x, yL); ctx.stroke();
    const bh = Math.max(1, Math.abs(yC - yO));
    ctx.fillRect(x - Math.max(1, cw * 0.32), Math.min(yO, yC), Math.max(1.4, cw * 0.64), bh);
  });
  ctx.fillStyle = "#8b97a8";
  ctx.font = "11px IBM Plex Mono, monospace";
  ctx.fillText(fmt(max, 6), 8, 12);
  ctx.fillText(fmt(min, 6), 8, h - 6);
}

function shell(inner) {
  const initials = (state.user?.name || "N").slice(0, 1).toUpperCase();
  const total = state.portfolio?.total_usd || 0;
  return `
    <div class="app-shell">
      <header class="topbar">
        <div class="brand"><div class="logo">N</div> NEXORA</div>
        <nav class="nav">
          ${["overview","markets","trade","wallet","orders","earn","settings"].map(v =>
            `<button class="${state.view===v?"active":""}" data-view="${v}">${t(v)}</button>`
          ).join("")}
        </nav>
        <div class="top-right">
          <div class="pill">${t("portfolio")} <b class="mono">${usd(total)}</b></div>
          <button class="btn ghost" id="langBtn">${state.lang === "en" ? "عربي" : "EN"}</button>
          <div class="avatar" title="${state.user?.email || ""}">${initials}</div>
        </div>
      </header>
      <main class="page">${inner}</main>
      <div class="footer-note">NEXORA demo · simulated balances · live public market prices when available · not financial advice</div>
    </div>`;
}

function viewAuth() {
  return `
    <div class="auth-wrap">
      <div class="card auth-card">
        <div class="brand"><div class="logo">N</div> NEXORA</div>
        <h1>Trade &amp; hold in one account</h1>
        <p class="sub">Spot trading, multi-asset wallet, convert, and earn — built as a complete local demo.</p>
        <div class="demo-box">
          Demo login<br/>
          <b class="mono">ammar@nexora.demo</b> / <b class="mono">demo1234</b><br/>
          Also: sara@nexora.demo / demo1234
        </div>
        <div class="tabs">
          <button class="on" id="tabLogin">Sign in</button>
          <button id="tabReg">Create account</button>
        </div>
        <form id="authForm">
          <div class="field hide" id="nameField"><label>Name</label><input name="name" placeholder="Your name" /></div>
          <div class="field"><label>Email</label><input name="email" type="email" value="ammar@nexora.demo" required /></div>
          <div class="field"><label>Password</label><input name="password" type="password" value="demo1234" required /></div>
          <button class="btn full" type="submit" id="authSubmit">Enter Nexora</button>
        </form>
        <p style="margin-top:14px;color:var(--dim);font-size:12px">${t("demo")}</p>
      </div>
    </div>`;
}

function viewOverview() {
  const p = state.portfolio || { assets: [], total_usd: 0 };
  const movers = [...state.markets].sort((a,b) => Math.abs(b.change24)-Math.abs(a.change24)).slice(0,6);
  return shell(`
    <div class="banner">${t("demo")}</div>
    <div class="grid-4">
      <div class="card"><h3>Total equity</h3><div class="stat mono">${usd(p.total_usd)}</div></div>
      <div class="card"><h3>Open orders</h3><div class="stat mono">${state.orders.filter(o=>o.status==="open").length}</div></div>
      <div class="card"><h3>Assets held</h3><div class="stat mono">${p.assets.filter(a=>a.available+a.locked>0).length}</div></div>
      <div class="card"><h3>Account</h3><div class="stat" style="font-size:18px">${state.user?.name || ""}</div><span class="kyc">${state.user?.kyc || "unverified"}</span></div>
    </div>
    <div class="grid-2" style="margin-top:16px">
      <div class="card">
        <h3>Holdings</h3>
        <table class="table">
          <thead><tr><th>Asset</th><th>Amount</th><th>Price</th><th>Value</th></tr></thead>
          <tbody>
            ${p.assets.filter(a=>a.available+a.locked>0).map(a=>`
              <tr>
                <td><b>${a.asset}</b><div style="color:var(--dim);font-size:11px">${a.name}</div></td>
                <td class="mono">${fmt(a.available + a.locked, 8)}</td>
                <td class="mono">${usd(a.price)}</td>
                <td class="mono">${usd(a.usd)}</td>
              </tr>`).join("")}
          </tbody>
        </table>
      </div>
      <div class="card">
        <h3>Market movers</h3>
        <table class="table">
          <thead><tr><th>Pair</th><th>Price</th><th>24h</th></tr></thead>
          <tbody>
            ${movers.map(m=>`
              <tr data-pair="${m.pair}" class="go-pair">
                <td><b>${m.pair}</b></td>
                <td class="mono">${fmt(m.price, 8)}</td>
                <td class="${clsCh(m.change24)} mono">${chTxt(m.change24)}</td>
              </tr>`).join("")}
          </tbody>
        </table>
      </div>
    </div>
  `);
}

function viewMarkets() {
  return shell(`
    <div class="card">
      <h3>Spot markets</h3>
      <table class="table">
        <thead><tr><th>Market</th><th>Last</th><th>24h</th><th>High</th><th>Low</th><th>Volume (USD)</th></tr></thead>
        <tbody>
          ${state.markets.map(m=>`
            <tr data-pair="${m.pair}" class="go-pair">
              <td><b>${m.pair}</b></td>
              <td class="mono">${fmt(m.price, 8)}</td>
              <td class="${clsCh(m.change24)} mono">${chTxt(m.change24)}</td>
              <td class="mono">${fmt(m.high24, 6)}</td>
              <td class="mono">${fmt(m.low24, 6)}</td>
              <td class="mono">${usd(m.vol24)}</td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>
  `);
}

function viewTrade() {
  const m = state.markets.find(x => x.pair === state.pair) || {};
  const [base, quote] = state.pair.split("/");
  const bookMax = Math.max(1, ...[...state.book.bids, ...state.book.asks].map(x => x.amount));
  const asks = [...(state.book.asks || [])].slice(0, 12).reverse();
  const bids = (state.book.bids || []).slice(0, 12);
  return shell(`
    <div class="trade-layout">
      <div class="card pair-list">
        <h3>Markets</h3>
        ${state.markets.map(x => `
          <button class="${x.pair===state.pair?"on":""}" data-pair="${x.pair}">
            <span>${x.pair}</span>
            <span class="mono ${clsCh(x.change24)}">${fmt(x.price,6)} ${chTxt(x.change24)}</span>
          </button>`).join("")}
      </div>
      <div>
        <div class="card" style="margin-bottom:14px">
          <div style="display:flex;justify-content:space-between;align-items:baseline">
            <div>
              <div style="font-size:22px;font-weight:700">${state.pair}</div>
              <div class="mono ${clsCh(m.change24||0)}">${fmt(m.price,8)} · ${chTxt(m.change24||0)}</div>
            </div>
            <div style="color:var(--muted);font-size:12px">H ${fmt(m.high24,6)} · L ${fmt(m.low24,6)}</div>
          </div>
          <div class="chart-box"><canvas id="chart"></canvas></div>
        </div>
        <div class="card">
          <h3>Recent trades</h3>
          <table class="table">
            <thead><tr><th>Price</th><th>Amount</th><th>Side</th></tr></thead>
            <tbody>
              ${(state.tape||[]).slice(0,8).map(tr=>`
                <tr><td class="mono ${tr.side==="buy"?"up":"down"}">${fmt(tr.price,8)}</td>
                <td class="mono">${fmt(tr.amount,6)}</td><td>${tr.side}</td></tr>`).join("")}
            </tbody>
          </table>
        </div>
      </div>
      <div>
        <div class="card book" style="margin-bottom:14px">
          <h3>Order book</h3>
          ${asks.map(r=>`
            <div class="book-row">
              <div class="bar" style="width:${r.amount/bookMax*100}%;background:var(--red);right:0;left:auto"></div>
              <span class="down mono">${fmt(r.price,6)}</span><span class="mono">${fmt(r.amount,4)}</span><span class="mono">${fmt(r.price*r.amount,2)}</span>
            </div>`).join("")}
          <div style="text-align:center;padding:8px 0;font-weight:700" class="mono">${fmt(m.price,8)}</div>
          ${bids.map(r=>`
            <div class="book-row">
              <div class="bar" style="width:${r.amount/bookMax*100}%;background:var(--green)"></div>
              <span class="up mono">${fmt(r.price,6)}</span><span class="mono">${fmt(r.amount,4)}</span><span class="mono">${fmt(r.price*r.amount,2)}</span>
            </div>`).join("")}
        </div>
        <div class="card">
          <div class="tabs">
            <button class="${state.side==="buy"?"on":""}" data-side="buy">Buy ${base}</button>
            <button class="${state.side==="sell"?"on":""}" data-side="sell">Sell ${base}</button>
          </div>
          <div class="tabs">
            <button class="${state.otype==="market"?"on":""}" data-otype="market">Market</button>
            <button class="${state.otype==="limit"?"on":""}" data-otype="limit">Limit</button>
          </div>
          <form id="orderForm">
            ${state.otype==="limit" ? `<div class="field"><label>Price (${quote})</label><input name="price" type="number" step="any" value="${m.price||""}" /></div>` : ""}
            <div class="field"><label>Amount (${base})</label><input name="amount" type="number" step="any" placeholder="0.00" required /></div>
            <button class="btn full ${state.side}" type="submit">${state.side==="buy"?"Buy":"Sell"} ${base}</button>
          </form>
        </div>
      </div>
    </div>
  `);
}

function viewWallet() {
  const p = state.portfolio || { assets: [] };
  const grouped = {};
  (state.addresses || []).forEach(a => {
    (grouped[a.asset] ||= []).push(a);
  });
  return shell(`
    <div class="grid-3">
      <div class="card"><h3>Total</h3><div class="stat mono">${usd(p.total_usd)}</div></div>
      <div class="card"><h3>Fiat</h3><div class="stat mono">${usd(p.assets.filter(a=>a.kind==="fiat"||a.kind==="stable").reduce((s,a)=>s+a.usd,0))}</div></div>
      <div class="card"><h3>Crypto</h3><div class="stat mono">${usd(p.assets.filter(a=>a.kind==="crypto").reduce((s,a)=>s+a.usd,0))}</div></div>
    </div>
    <div class="grid-2" style="margin-top:16px">
      <div class="card">
        <h3>Balances</h3>
        <table class="table">
          <thead><tr><th>Asset</th><th>Available</th><th>Locked</th><th>USD</th></tr></thead>
          <tbody>
            ${(p.assets||[]).map(a=>`
              <tr>
                <td><b>${a.asset}</b></td>
                <td class="mono">${fmt(a.available,8)}</td>
                <td class="mono">${fmt(a.locked,8)}</td>
                <td class="mono">${usd(a.usd)}</td>
              </tr>`).join("")}
          </tbody>
        </table>
      </div>
      <div>
        <div class="card" style="margin-bottom:14px">
          <h3>Deposit (instant simulation)</h3>
          <form id="depForm">
            <div class="split">
              <div class="field"><label>Asset</label>
                <select name="asset">${Object.keys(grouped).map(a=>`<option>${a}</option>`).join("")}</select>
              </div>
              <div class="field"><label>Amount</label><input name="amount" type="number" step="any" required /></div>
            </div>
            <button class="btn full" type="submit">Credit wallet</button>
          </form>
          <div id="addrBox" style="margin-top:10px;color:var(--muted);font-size:12px" class="mono"></div>
        </div>
        <div class="card" style="margin-bottom:14px">
          <h3>Withdraw</h3>
          <form id="wdForm">
            <div class="field"><label>Asset</label><select name="asset">${(p.assets||[]).map(a=>`<option>${a.asset}</option>`).join("")}</select></div>
            <div class="field"><label>Amount</label><input name="amount" type="number" step="any" required /></div>
            <div class="field"><label>Destination address</label><input name="address" required placeholder="External address" /></div>
            <button class="btn ghost full" type="submit">Withdraw</button>
          </form>
        </div>
        <div class="card" style="margin-bottom:14px">
          <h3>Internal transfer</h3>
          <form id="tfForm">
            <div class="field"><label>Recipient email</label><input name="email" value="sara@nexora.demo" required /></div>
            <div class="split">
              <div class="field"><label>Asset</label><select name="asset">${(p.assets||[]).map(a=>`<option>${a.asset}</option>`).join("")}</select></div>
              <div class="field"><label>Amount</label><input name="amount" type="number" step="any" required /></div>
            </div>
            <button class="btn ghost full" type="submit">Send on Nexora</button>
          </form>
        </div>
        <div class="card">
          <h3>Convert</h3>
          <form id="cvForm">
            <div class="split">
              <div class="field"><label>From</label><select name="from">${(p.assets||[]).map(a=>`<option>${a.asset}</option>`).join("")}</select></div>
              <div class="field"><label>To</label><select name="to">${(p.assets||[]).map(a=>`<option ${a.asset==="USDT"?"selected":""}>${a.asset}</option>`).join("")}</select></div>
            </div>
            <div class="field"><label>Amount</label><input name="amount" type="number" step="any" required /></div>
            <button class="btn full" type="submit">Convert · 0.15% fee</button>
          </form>
        </div>
      </div>
    </div>
  `);
}

function viewOrders() {
  return shell(`
    <div class="grid-2">
      <div class="card">
        <h3>Orders</h3>
        <table class="table">
          <thead><tr><th>Pair</th><th>Side</th><th>Type</th><th>Amount</th><th>Status</th><th></th></tr></thead>
          <tbody>
            ${state.orders.map(o=>`
              <tr>
                <td>${o.pair}</td><td class="${o.side==="buy"?"up":"down"}">${o.side}</td>
                <td>${o.type}</td><td class="mono">${fmt(o.filled,6)}/${fmt(o.amount,6)}</td>
                <td>${o.status}</td>
                <td>${o.status==="open"?`<button class="btn ghost cancel" data-id="${o.id}">Cancel</button>`:""}</td>
              </tr>`).join("") || `<tr><td colspan="6" style="color:var(--dim)">No orders yet</td></tr>`}
          </tbody>
        </table>
      </div>
      <div class="card">
        <h3>Fills &amp; wallet activity</h3>
        <table class="table">
          <thead><tr><th>Type</th><th>Asset</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody>
            ${state.txs.slice(0,20).map(x=>`
              <tr><td>${x.kind}</td><td>${x.asset}</td><td class="mono">${fmt(x.amount,8)}</td><td>${x.status}</td></tr>
            `).join("") || `<tr><td colspan="4" style="color:var(--dim)">No activity</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `);
}

function viewEarn() {
  return shell(`
    <div class="banner">Flexible demo staking. Rewards accrue in-app. Terms are simulated APR only.</div>
    <div class="grid-2">
      <div class="card">
        <h3>Stake</h3>
        <form id="stForm">
          <div class="field"><label>Asset</label>
            <select name="asset"><option>USDT</option><option>ETH</option><option>SOL</option><option>TON</option></select>
          </div>
          <div class="field"><label>Amount</label><input name="amount" type="number" step="any" required /></div>
          <div class="field"><label>Lock</label>
            <select name="days"><option value="30">30 days · base APR</option><option value="90">90 days</option><option value="180">180 days</option></select>
          </div>
          <p style="color:var(--muted);font-size:12px;margin-bottom:10px">USDT 8% · SOL 6.5% · TON 5.5% · ETH 4.5% APR</p>
          <button class="btn full" type="submit">Lock &amp; earn</button>
        </form>
      </div>
      <div class="card">
        <h3>Positions</h3>
        <table class="table">
          <thead><tr><th>Asset</th><th>Amount</th><th>APR</th><th>Status</th><th>Accrued</th></tr></thead>
          <tbody>
            ${state.stakes.map(s=>`
              <tr>
                <td>${s.asset}</td><td class="mono">${fmt(s.amount,6)}</td>
                <td>${(s.apr*100).toFixed(1)}%</td><td>${s.status}</td>
                <td class="mono">${fmt(s.reward||0,6)}</td>
              </tr>`).join("") || `<tr><td colspan="5" style="color:var(--dim)">No stakes</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `);
}

function viewSettings() {
  return shell(`
    <div class="grid-2">
      <div class="card">
        <h3>Profile</h3>
        <form id="pfForm">
          <div class="field"><label>Name</label><input name="name" value="${state.user?.name || ""}" /></div>
          <div class="field"><label>Email</label><input value="${state.user?.email || ""}" disabled /></div>
          <div class="field"><label>Language</label>
            <select name="lang"><option value="en" ${state.lang==="en"?"selected":""}>English</option><option value="ar" ${state.lang==="ar"?"selected":""}>العربية</option></select>
          </div>
          <button class="btn" type="submit">Save</button>
        </form>
      </div>
      <div class="card">
        <h3>Security &amp; account</h3>
        <p style="color:var(--muted);margin-bottom:12px">KYC status: <span class="kyc">${state.user?.kyc}</span><br/>Referral: <b class="mono">${state.user?.referral || "—"}</b></p>
        <button class="btn ghost" id="logout">Sign out</button>
        <p style="margin-top:16px;color:var(--dim);font-size:12px">Passwords are hashed with PBKDF2 on this machine. Do not use a real banking password. This server is a local demo.</p>
      </div>
    </div>
  `);
}

function render() {
  document.documentElement.lang = state.lang;
  document.documentElement.dir = state.lang === "ar" ? "rtl" : "ltr";
  if (!state.token || !state.user) {
    app.innerHTML = viewAuth();
    bindAuth();
    return;
  }
  const views = {
    overview: viewOverview,
    markets: viewMarkets,
    trade: viewTrade,
    wallet: viewWallet,
    orders: viewOrders,
    earn: viewEarn,
    settings: viewSettings,
  };
  app.innerHTML = (views[state.view] || viewOverview)();
  bindApp();
  if (state.view === "trade") {
    const c = $("#chart");
    if (c) drawChart(c, state.candles);
  }
  if (state.view === "wallet") updateAddrHint();
}

function bindAuth() {
  let mode = "login";
  $("#tabLogin").onclick = () => {
    mode = "login";
    $("#tabLogin").classList.add("on");
    $("#tabReg").classList.remove("on");
    $("#nameField").classList.add("hide");
    $("#authSubmit").textContent = "Enter Nexora";
  };
  $("#tabReg").onclick = () => {
    mode = "register";
    $("#tabReg").classList.add("on");
    $("#tabLogin").classList.remove("on");
    $("#nameField").classList.remove("hide");
    $("#authSubmit").textContent = "Create account";
  };
  $("#authForm").onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const body = Object.fromEntries(fd.entries());
    try {
      const data = await api(mode === "login" ? "/api/login" : "/api/register", {
        method: "POST", body: JSON.stringify(body),
      });
      state.token = data.token;
      state.user = data.user;
      localStorage.setItem("nexora_token", data.token);
      toast("Welcome, " + data.user.name);
      await boot();
    } catch (err) { toast(err.message); }
  };
}

function bindApp() {
  document.querySelectorAll("[data-view]").forEach(b => {
    b.onclick = async () => { state.view = b.dataset.view; await refreshView(); };
  });
  document.querySelectorAll("[data-pair]").forEach(b => {
    b.onclick = async () => { state.pair = b.dataset.pair; state.view = "trade"; await refreshView(); };
  });
  document.querySelectorAll("[data-side]").forEach(b => {
    b.onclick = () => { state.side = b.dataset.side; render(); };
  });
  document.querySelectorAll("[data-otype]").forEach(b => {
    b.onclick = () => { state.otype = b.dataset.otype; render(); };
  });
  const langBtn = $("#langBtn");
  if (langBtn) langBtn.onclick = () => {
    state.lang = state.lang === "en" ? "ar" : "en";
    localStorage.setItem("nexora_lang", state.lang);
    render();
  };
  const of = $("#orderForm");
  if (of) of.onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(of);
    try {
      const data = await api("/api/orders", {
        method: "POST",
        body: JSON.stringify({
          pair: state.pair, side: state.side, type: state.otype,
          amount: fd.get("amount"), price: fd.get("price"),
        }),
      });
      state.portfolio = data.portfolio;
      toast(`${data.order.status === "filled" ? "Filled" : "Placed"} ${data.order.side} ${data.order.pair}`);
      await refreshView();
    } catch (err) { toast(err.message); }
  };
  document.querySelectorAll(".cancel").forEach(b => {
    b.onclick = async () => {
      try { await api("/api/orders/" + b.dataset.id, { method: "DELETE" }); toast("Cancelled"); await refreshView(); }
      catch (err) { toast(err.message); }
    };
  });
  const hook = (id, path, extra) => {
    const f = $(id);
    if (!f) return;
    f.onsubmit = async (e) => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(f).entries());
      try {
        const data = await api(path, { method: "POST", body: JSON.stringify(body) });
        if (data.portfolio) state.portfolio = data.portfolio;
        toast("Done");
        await refreshView();
      } catch (err) { toast(err.message); }
    };
  };
  hook("#depForm", "/api/wallet/deposit");
  hook("#wdForm", "/api/wallet/withdraw");
  hook("#tfForm", "/api/wallet/transfer");
  hook("#cvForm", "/api/convert");
  hook("#stForm", "/api/stake");
  const pf = $("#pfForm");
  if (pf) pf.onsubmit = async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(pf).entries());
    try {
      const data = await api("/api/profile", { method: "POST", body: JSON.stringify(body) });
      state.user = data.user;
      state.lang = body.lang || state.lang;
      toast("Saved");
      render();
    } catch (err) { toast(err.message); }
  };
  const lo = $("#logout");
  if (lo) lo.onclick = () => {
    state.token = ""; state.user = null;
    localStorage.removeItem("nexora_token");
    render();
  };
}

function updateAddrHint() {
  const box = $("#addrBox");
  const sel = document.querySelector("#depForm select[name=asset]");
  if (!box || !sel) return;
  const show = () => {
    const rows = (state.addresses || []).filter(a => a.asset === sel.value);
    box.textContent = rows.map(r => r.network + ": " + r.address).join("  ·  ");
  };
  sel.onchange = show;
  show();
}

async function refreshView() {
  try {
    const [me, mk] = await Promise.all([api("/api/me"), api("/api/markets")]);
    state.user = me.user;
    state.portfolio = me.portfolio;
    state.markets = mk.markets;
    if (state.view === "trade") {
      const [ob, cd, tp] = await Promise.all([
        api("/api/orderbook/" + state.pair),
        api("/api/candles/" + state.pair),
        api("/api/tape/" + state.pair),
      ]);
      state.book = ob; state.candles = cd.candles; state.tape = tp.trades;
    }
    if (state.view === "wallet") {
      const w = await api("/api/wallet");
      state.portfolio = w.portfolio; state.addresses = w.addresses;
    }
    if (state.view === "orders") {
      const [o, tx] = await Promise.all([api("/api/orders"), api("/api/transactions")]);
      state.orders = o.orders; state.txs = tx.txs;
    }
    if (state.view === "overview") {
      const o = await api("/api/orders");
      state.orders = o.orders;
    }
    if (state.view === "earn") {
      const s = await api("/api/stake");
      state.stakes = s.stakes;
    }
  } catch (err) {
    if (String(err.message).toLowerCase().includes("sign in")) {
      state.token = ""; localStorage.removeItem("nexora_token");
    } else toast(err.message);
  }
  render();
}

async function boot() {
  if (!state.token) { render(); return; }
  try {
    await refreshView();
  } catch {
    state.token = ""; render();
  }
}

setInterval(() => {
  if (state.token && (state.view === "trade" || state.view === "markets" || state.view === "overview")) {
    refreshView();
  }
}, 9000);

boot();
