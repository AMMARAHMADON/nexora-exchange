# NEXORA Exchange & E-Wallet

Complete **demo** trading platform and multi-asset wallet you can run on one machine.

This is a simulation. It is **not** a licensed exchange, broker, or payment institution. Prices may be pulled from public market APIs; balances and fills are local and fictional.

## What is included

- Accounts: register / sign in, session tokens, PBKDF2 password hashing
- Spot markets: BTC, ETH, SOL, BNB, XRP, DOGE, TON vs USDT, plus ETH/BTC
- Live-ish prices from CoinGecko when the network allows, otherwise a random walk
- Candlestick chart, order book, trade tape
- Market and limit orders with a simple matching engine
- Wallet: balances, deposit addresses, simulated deposit / withdraw
- Internal transfer between Nexora users
- Convert / swap with a 0.15% fee
- Earn: lock USDT, ETH, SOL, or TON
- Orders, fills, and full transaction history
- English / العربية toggle
- Demo users with funded wallets

## Run

```bash
cd nexora-exchange
python3 server.py
```

Open http://127.0.0.1:8080

Optional:

```bash
NEXORA_PORT=9000 python3 server.py
```

## Demo login

| Email | Password | Notes |
| --- | --- | --- |
| ammar@nexora.demo | demo1234 | Funded portfolio (BTC, ETH, fiat, …) |
| sara@nexora.demo | demo1234 | Second account — use for internal transfers |

New registrations start with 10,000 USDT and 5,000 AED.

## Stack

- Backend: Python 3 standard library (`http.server`, `sqlite3`)
- Database: `data/nexora.db`
- Frontend: static HTML / CSS / JS (no build step)

## API sketch

- `POST /api/register` `{name,email,password}`
- `POST /api/login` `{email,password}`
- `GET /api/me`
- `GET /api/markets`
- `GET /api/orderbook/BTC/USDT`
- `GET /api/candles/BTC/USDT`
- `POST /api/orders` `{pair,side,type,amount,price}`
- `DELETE /api/orders/:id`
- `GET /api/wallet`
- `POST /api/wallet/deposit` `{asset,amount}`
- `POST /api/wallet/withdraw` `{asset,amount,address}`
- `POST /api/wallet/transfer` `{email,asset,amount}`
- `POST /api/convert` `{from,to,amount}`
- `POST /api/stake` `{asset,amount,days}`

Send `Authorization: Bearer <token>` on private routes.

## Not included (by design)

Real bank rails, on-chain settlement, KYC vendor, custody, margin, derivatives, or production-grade matching. Those require licenses, capital, and an engineering team.
